import requests
import pyodbc
from datetime import datetime, timezone
from auth import ACCESS_TOKEN, IG_USER_ID, BASE_URL, DBConnection

START_DATE = "2022-01-01"

def fix_ts_to_utc(ts: str):
    """Normaliza 'YYYY-MM-DDTHH:MM:SS+0000' -> datetime (UTC naive) para SQL Server."""
    if not ts:
        return None
    # ...+HHMM -> ...+HH:MM
    if len(ts) >= 5 and (ts[-5] in ['+', '-']) and ts[-3:].isdigit() and ts[-5:-3].isdigit():
        ts = ts[:-5] + ts[-5:-3] + ":" + ts[-3:]
    try:
        dt = datetime.fromisoformat(ts)
        if dt.tzinfo:
            dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
        return dt
    except Exception:
        try:
            return datetime.strptime(ts[:19], "%Y-%m-%dT%H:%M:%S")
        except Exception:
            return datetime.utcnow()

def get_json(url, params=None, label=""):
    """GET com logs de erro úteis para depuração."""
    try:
        resp = requests.get(url, params=params, timeout=30)
        if resp.status_code != 200:
            print(f"[HTTP {resp.status_code}] {label or url}")
            print("URL:", resp.url)
            print("Body:", resp.text[:800])
            return {}
        return resp.json()
    except Exception as e:
        print(f"[ERRO REQ] {label or url}: {e}")
        return {}

def upsert_collab(cursor, id_post, partner_id, username, status):
    """
    UPSERT em IG_COLLAB respeitando UNIQUE (ID_POST, PARTNER_ID, INVITE_STATUS).
    1) UPDATE-first: se já existir, atualiza USERNAME/UPDATEDAT.
    2) Se não existir, INSERT.
    """
    cursor.execute("""
        UPDATE IG_COLLAB
           SET PARTNER_USERNAME = COALESCE(?, PARTNER_USERNAME),
               UPDATEDAT        = GETDATE()
         WHERE ID_POST = ?
           AND PARTNER_ID = ?
           AND INVITE_STATUS = ?
    """, username, id_post, partner_id, status)
    if cursor.rowcount == 0:
        cursor.execute("""
            INSERT INTO IG_COLLAB
              (ID_POST, PARTNER_ID, PARTNER_USERNAME, INVITE_STATUS, CREATEDAT, UPDATEDAT)
            VALUES (?, ?, ?, ?, GETDATE(), GETDATE())
        """, id_post, partner_id, username, status)

# 1) Conexão SQL
conn = pyodbc.connect(DBConnection)
cursor = conn.cursor()

# 2) Primeira página de /media
url = f"{BASE_URL}/{IG_USER_ID}/media"
params = {
    "fields": "id,media_type,permalink,timestamp,like_count,comments_count",
    "access_token": ACCESS_TOKEN,
    "since": START_DATE
}

total_ig_data = 0
total_ig_postdata = 0
total_ig_collab = 0
pagina = 0

while url:
    pagina += 1
    r = get_json(url, params=params, label=f"/media page {pagina}")
    data = r.get("data") or []
    if not data and not r.get("paging"):
        break

    for post in data:
        id_post = post.get("id")
        if not id_post:
            continue

        media_type = post.get("media_type")
        permalink  = post.get("permalink")
        post_date  = fix_ts_to_utc(post.get("timestamp"))
        likes      = int(post.get("like_count") or 0)
        comments   = int(post.get("comments_count") or 0)

        # --- IG_DATA (histórico: sempre insere)
        try:
            cursor.execute("""
                INSERT INTO IG_DATA
                  (ID_POST, MEDIA_TYPE, PERMALINK, POST_DATE, LIKES_COUNT, COMMENTS_COUNT, IS_COLLAB, CREATEDAT, UPDATEDAT)
                VALUES (?, ?, ?, ?, ?, ?, 0, GETDATE(), GETDATE())
            """, id_post, media_type, permalink, post_date, likes, comments)
            conn.commit()
            total_ig_data += 1
        except Exception as e:
            print(f"[ERRO SQL IG_DATA {id_post}] {e}")
            conn.rollback()

        # --- Insights do post
        ir = get_json(
            f"{BASE_URL}/{id_post}/insights",
            params={"metric": "reach,views,saved", "access_token": ACCESS_TOKEN},
            label=f"/insights {id_post}"
        )
        reach = views = saves = 0
        for item in (ir.get("data") or []):
            name = item.get("name")
            vals = item.get("values") or []
            if not vals:
                continue
            v = int(vals[0].get("value") or 0)
            if name == "reach":  reach = v
            if name == "views":  views = v
            if name == "saved":  saves = v

        try:
            cursor.execute("""
                INSERT INTO IG_POSTDATA
                  (ID_POST, SAVES_COUNT, REACH_COUNT, VIEWS_COUNT, CREATEDAT, UPDATEDAT)
                VALUES (?, ?, ?, ?, GETDATE(), GETDATE())
            """, id_post, saves, reach, views)
            conn.commit()
            total_ig_postdata += 1
        except Exception as e:
            print(f"[ERRO SQL IG_POSTDATA {id_post}] {e}")
            conn.rollback()

        # --- Collaborators do post (UPSERT)
        collab = get_json(
            f"{BASE_URL}/{id_post}/collaborators",
            params={"access_token": ACCESS_TOKEN},
            label=f"/collaborators {id_post}"
        )
        partners = collab.get("data") or []
        tem_collab = False

        for c in partners:
            partner_id = c.get("id")  # IG user id do colaborador
            username = c.get("username") or c.get("ig_username") or c.get("name")
            status   = c.get("invite_status") or c.get("status") or c.get("invitation_status")

            # fallback para username via /{partner_id}
            if partner_id and not username:
                u = get_json(f"{BASE_URL}/{partner_id}",
                             params={"fields": "username", "access_token": ACCESS_TOKEN},
                             label=f"/user {partner_id}")
                username = (u or {}).get("username")

            try:
                upsert_collab(cursor, id_post, partner_id, username, status)
                conn.commit()
                total_ig_collab += 1
                tem_collab = True
            except Exception as e:
                print(f"[ERRO SQL IG_COLLAB {id_post}/{partner_id}] {e}")
                conn.rollback()

            # opcional: respeitar rate limit se tiver muitos colaboradores
            # time.sleep(0.2)

        # marcar flag de collab no snapshot mais recente do post
        if tem_collab:
            try:
                cursor.execute("""
                    UPDATE IG_DATA
                       SET IS_COLLAB = 1, UPDATEDAT = GETDATE()
                     WHERE IDIG = (
                         SELECT TOP 1 IDIG
                         FROM IG_DATA
                         WHERE ID_POST = ?
                         ORDER BY UPDATEDAT DESC
                     )
                """, id_post)
                conn.commit()
            except Exception as e:
                print(f"[ERRO SQL update IS_COLLAB {id_post}] {e}")
                conn.rollback()

        # opcional: respeitar rate limit geral
        # time.sleep(0.1)

    # 4) Próxima página (usar só a URL 'next'; não repetir params)
    url = r.get("paging", {}).get("next")
    params = None

# 5) Finalização
cursor.close()
conn.close()

print(f"[OK] IG_DATA inseridos: {total_ig_data}")
print(f"[OK] IG_POSTDATA inseridos: {total_ig_postdata}")
print(f"[OK] IG_COLLAB upsertados: {total_ig_collab}")