# API Auth
ACCESS_TOKEN = "Insira seu Token Aqui"
IG_USER_ID = "Insira seu USER ID do Instagram aqui"
BASE_URL = "https://graph.facebook.com/v23.0" 

# DB Auth - Necessário instalar OLE Driver 17 para SQL Server. 
DBConnection = "DRIVER={ODBC Driver 17 for SQL Server};SERVER=localhost;DATABASE=APIS_MKT;UID=sa;PWD=sa"